package com.eaton.kafka.confluent.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.eaton.kafka.confluent.service.ProducerService;

@RestController
public class Controller {

	@Autowired
	ProducerService producer;

	@PostMapping("/produce")
	public ResponseEntity<String> produce(@RequestParam String topic, @RequestParam(required = false) String key,
			@RequestParam String message) {
		producer.send(topic, key, message);
		return ResponseEntity.ok("Message sent to topic: " + topic);
	}
}
