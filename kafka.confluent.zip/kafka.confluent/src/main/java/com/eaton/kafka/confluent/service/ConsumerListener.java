package com.eaton.kafka.confluent.service;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class ConsumerListener {

	@KafkaListener(topics = "topic_test", groupId = "java-group-1",concurrency = "3")
	public void listen(ConsumerRecord<String, String> record) throws Exception {
		System.out.printf("Thread %s Consumed: topic=%s partition=%d offset=%d key=%s value=%s%n", 
				Thread.currentThread().getName(),
				record.topic(),
				record.partition(), 
				record.offset(), 
				record.key(), 
				record.value());
	}
}
