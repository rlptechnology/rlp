package com.eaton.kafka.confluent.service;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class ProducerService {

	private final KafkaTemplate<String, String> kafkaTemplate;
	private static final String TOPIC = "topic_test";

	public ProducerService(KafkaTemplate<String, String> kafkaTemplate) {
		this.kafkaTemplate = kafkaTemplate;
	}

	public void send(String topic, String key, String message) {
		if (key == null || key.isBlank()) {
			kafkaTemplate.send(TOPIC,null, message);
		} else {
			kafkaTemplate.send(TOPIC, key, message);
		}

	}

}
